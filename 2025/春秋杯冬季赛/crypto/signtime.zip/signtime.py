from hashlib import sha1
from Crypto.Util.number import bytes_to_long
from ecdsa.ecdsa import Public_key, Private_key, Signature, generator_192
from datetime import datetime
from random import randrange

banner = """                                                
    //   / /     //   ) )     //    ) )     //   ) )     // | | 
   //____       //           //    / /     ((           //__| | 
  / ____       //           //    / /        \\         / ___  | 
 //           //           //    / /           ) )    //    | | 
//____/ /    ((____/ /    //____/ /     ((___ / /    //     | |  

Welcome to this CTF challenge!
you have THREE choices:
- sign_time to get a signature
- verify to verify the signature
- I kown the secret to get the flag
You only have TWO chances per connection. Best wish for you!
"""


generator = generator_192
order = generator.order()
hint_message = ''
flag_content = ''

private_key_value = randrange(1, order - 1)
public_key = Public_key(generator, generator * private_key_value)
private_key = Private_key(public_key, private_key_value)

def sign_current_time():
    current_time = datetime.now()
    current_month = int(current_time.strftime("%m"))  
    current_seconds = int(current_time.strftime("%S"))  
    formatted_time = f"{current_month}:{current_seconds}"
    message = f"The time is {formatted_time}"
    message_hash = sha1(message.encode()).digest()  
    signature = private_key.sign(bytes_to_long(message_hash), randrange(100, 100 + current_seconds))  
    return {"time": message, "r": hex(signature.r), "s": hex(signature.s)}

def verify_signature():
    user_message = input("Enter the message: ")
    user_r = input("Enter r in hexadecimal form: ")
    user_s = input("Enter s in hexadecimal form: ")
    message_hash = sha1(user_message.encode()).digest() 
    signature_r = int(user_r, 16)
    signature_s = int(user_s, 16)
    signature = Signature(signature_r, signature_s)  
    return public_key.verifies(bytes_to_long(message_hash), signature)

def start_challenge():
    print(banner)
    for _ in range(2):
        user_choice = input("Enter your option: ")
        if user_choice == 'sign_time':
            print(sign_current_time())
        elif user_choice == 'verify':
            if verify_signature():
                print(f"The hint is: {hint_message}")
                exit(0)
            else:
                print("Signature verification failed.")
        elif user_choice  == 'I kown the secret':
                if input("Enter the secret: ") == hex(private_key_value):
                    print(f"The flag is: {flag_content}")
                    exit(0)
        else:
            print("Invalid option!")


    
if __name__ == "__main__":
    start_challenge()
