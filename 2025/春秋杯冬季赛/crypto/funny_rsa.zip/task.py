import random
import libnum
from Crypto.Util.number import bytes_to_long, long_to_bytes

print("Welcome to ChunqiuCTF Game!")
print("接下来完成下面的挑战")
print("Good luck!")

# funny
hint = b' '
m = b' '
p = libnum.generate_prime(1024)
q = libnum.generate_prime(1024)
n = p * q

print("give you some funny numbers")
# funny 1
print(p+q - p*q + random.randint(-1025, +1025)) 
# funny 2
print(bytes_to_long(m)*bytes_to_long(hint))
# funny 3
print(bytes_to_long(m)*n*bytes_to_long(hint) - 1025)
# funny 4
print(pow(bytes_to_long(hint), 65537, n))




