<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form action="upload_file.php" method="post" enctype="multipart/form-data">
	<input type="file" name="file">
	<input type="submit" name="submit" value="submit">

</form>


</body>
</html>

